#include "simpleFS.h"

int main(int argc, char **argv)
{
    /* TODO:
     * Implement :)
     */

    return 0;
}
