// Initialize a filesystem of the size specified in number of data blocks
void init_filesystem(unsigned int size, char *real_path, unsigned int n)
{
    /*
     * You first need to initalize a superblock. Write that to disk.
     * Create the bitmaps for block_bm and inode_bm.
     * write both to disk
     * Make a 5 block large inode table.
     * Then initialize the "size" datablocks.
     *
     * Also, when this is all done. you should have a file system ready.
     * with a parent directory of '/' at inode 2.
     */
}
void open_filesystem(char *real_path, unsigned int n)
{
    /*
     * You will need to open an existing file system image from disk.
     * Read the file system information from the disk and initialize the
     * in-memory variables to match what was on disk.
     * use this file system for everything from now on.
     * Fail if the magic signature doesn't match
     */
}
void make_directory(char *path, unsigned int n)
{
    /*
     * For the file system image that is currently opened.
     * Make a new directory at the path provided.
     * Make sure that the path is valid.
     */
}
unsigned int read_directory(char *path, unsigned int n, char *data)
{
    /*
     * For the file system image that is currently opened.
     * Read the contents of the directory in the path provided.
     * Make sure that the path is valid.
     * Place the directory entries in data.
     * and return the number of bytes that have been placed in data.
     */
}
void rm_directory(char *path, unsigned int n)
{
    /*
     * For the file system image that is currently opened.
     * Delete the directory in the path provided.
     * Make sure that the directory doesn't have any files remaining
     */
}
void create_file(char *path, unsigned int n, unsigned int size, char *data)
{
    /*
     * For the file system image that is currently opened.
     * Create a new file at path.
     * Make sure that the path is valid.
     * Write to the contents of the file in the data provided.
     * size is the number of bytes in the data.
     */
}
void rm_file(char *path, unsigned int n)
{
    /*
     * For the file system image that is currently opened.
     * Delete the file in the path provided.
     * Make sure that the data blocks are freed after deleting the file.
     */
}
unsigned int read_file(char *path, unsigned int n, char *data)
{
    /*
     * For the file system image that is currently opened.
     * Read the contents of the file in the path provided.
     * Make sure that the path is valid.
     * Place the file contents in data
     * and return the number of bytes in the file.
     */
}
void make_link(char *path, unsigned int n, char *target)
{
    /*
     * make a new hard link in the path to target
     * make sure that the path and target are both valid.
     */
}
